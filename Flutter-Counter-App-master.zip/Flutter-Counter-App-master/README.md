# Flutter Counter App
<a href="https://stackoverflow.com/questions/tagged/flutter?sort=votes">
   
   
   
   <img alt="Awesome Flutter" src="https://img.shields.io/badge/Awesome-Flutter-blue.svg?longCache=true&style=flat-square" />
</a>
</br>
 Just an Counter UI using Flutter
 
# UI
![Preview](./gif/App.gif?raw=true 'android')

# Thank _You_!
Please :star: this repo and share it with others

### Created By

* [Raj Chowdhury](https://github.com/Rajchowdhury420)
